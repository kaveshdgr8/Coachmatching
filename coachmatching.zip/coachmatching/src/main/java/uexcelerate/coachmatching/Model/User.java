package uexcelerate.coachmatching.Model;

import org.neo4j.ogm.annotation.GraphId;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import com.sun.tools.javac.util.List;

@NodeEntity
public class User {
	
	@GraphId
	private long id;
	private String name;
	private long email;
	
	@Relationship(type="Rated", direction = Relationship.INCOMING)
	private List coaches;
	
	public List getCoaches(){
		return coaches;
	}
	public User() {
		 
	}

	public long getId( ) {
		return id;
	}
	
	public String getName( ) {
		return name;
	}

	public long getemail() {
		return email;
	}
}
