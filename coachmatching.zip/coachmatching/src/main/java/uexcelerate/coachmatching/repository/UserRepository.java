package uexcelerate.coachmatching.repository;

import java.util.Collection;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;

import uexcelerate.coachmatching.Model.User;

public interface UserRepository extends Neo4jRepository<User,Long> {
	
	@Query("MATCH (u:User)<-[r:Rated]-(c:Coach) Return u,r,c")
	Collection<User> getAllUsers();

}
